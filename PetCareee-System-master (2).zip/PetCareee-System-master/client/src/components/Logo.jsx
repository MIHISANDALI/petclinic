import React from 'react'

export default function Logo() {
  return (
    <div className=' w-full h-[100px] bg-red-600 mt-0'>

      <div className='flex justify-center items-center'><h className="text-white text-4xl font-serif mt-8">Pet Clinic</h></div>
    </div>
  )
}
