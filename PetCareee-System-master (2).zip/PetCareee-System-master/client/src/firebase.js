// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: "blog-admin-1e875.firebaseapp.com",
  projectId: "blog-admin-1e875",
  storageBucket: "blog-admin-1e875.appspot.com",
  messagingSenderId: "78719536174",
  appId: "1:78719536174:web:9b071aaf32849e9cb6e3bf"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);